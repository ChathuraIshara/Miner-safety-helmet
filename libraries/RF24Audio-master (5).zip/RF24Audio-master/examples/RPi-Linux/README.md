 **RF24Audio Example for RPi/Linux**
 
 1. Clone RF24Audio into same directory as RF24 directory is located
 2. Configure radio CE/CS pins in audio.cpp then 'make'
 3. Run ' sudo ./audio '
 4. Arduino should be configured with RF24Audio gettingstarted sketch to receive the audio
 
 